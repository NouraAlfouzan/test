A Pen created at CodePen.io. You can find this one at http://codepen.io/soulrider911/pen/dGuEn.

 Fun example of a sticky header utilizing some CSS3 transitions!