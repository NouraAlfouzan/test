<!DOCTYPE html>
<html >
<head>

  <meta charset="UTF-8">
  <title>Home</title>
      
	  <script type="text/javascript" src="script.js"></script>
	   <script src="https://kit.fontawesome.com/ff4e223e2d.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style.css">
	  
   
</head>

<body>
 
  <header>
  <img class="attach" id="logopic" src="images/logo.png" alt="logo" width="20%" > 
 
   
	
     
	
 <nav>
<?php
session_start();
        if(!isset($_SESSION['entered'])){
            echo '<a href="index.php">Home</a>';
            echo '<a href="#real">Categories</a>';
            echo '<a href="log in.php">Admin log-in</a>';
	    echo '<a href="sign-up.php">New admin? sign-up</a>';
        }
        
        else{
            echo '<a href="AdminHome.php">Home</a>';
            echo '<a href="LogOut.php"> Log-out</a>';
        }
?>
</nav>
  </header>
  
   <main>
  <div class="wrapper">
  
    <section id='steezy'>
	  <h2 id ="home-title"> Enjoy sailing in the world of technology! </h2>
     <article>
<div class = "slide-show">

<div id="slider">
   <input type="radio" name="slider" id="slide1" checked>
   <input type="radio" name="slider" id="slide2">
   <input type="radio" name="slider" id="slide3">
   <input type="radio" name="slider" id="slide4">
   <div id="slides">
      <div id="overflow">
         <div class="inner">
            <div class="slide slide_1">
               <div class="slide-content">
                  <p><img src="images/groub.JPG" alt="slide1"></p>
               </div>
            </div>
            <div class="slide slide_2">
               <div class="slide-content">
                  <p><img src="images/taplet.JPG" alt="slide2"></p>
               </div>
            </div>
            <div class="slide slide_3">
               <div class="slide-content">
                  <p><img src="images/Lap.JPG" style="width:60%" alt="slide3"></p>
               </div>
            </div>
            <div class="slide slide_4">
               <div class="slide-content">
                  <p><img src="images/ipadh.JPG" alt="slide4"></p>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div id="controls">
      <label for="slide1"></label>
      <label for="slide2"></label>
      <label for="slide3"></label>
      <label for="slide4"></label>
   </div>
   <div id="bullets">
      <label for="slide1"></label>
      <label for="slide2"></label>
      <label for="slide3"></label>
      <label for="slide4"></label>
   </div>
</div>
</div>
</article>
    </section>

    <section id='real'>
	
     <div id="wrapper">
    <div id="gallery" class="clearfix">
      <figure>
        <img src="images/APPS.png" alt="tree sketching"  >
      </br>
		</br>
		<input type="button" id="Programs-catogery" value="Programs" onclick=""> 
		<script type="text/javascript">
    document.getElementById("Programs-catogery").onclick = function () {
        location.href = "ProgramPage.php";
    };
</script>
		</br>
		</br>
      </figure>
      
     
      
      <figure>
        <img src="images/de.png" alt="Puppy Love">
       </br>
		</br>
		<input type="button" id="Devices-catogery" value="Devices" onclick=""> 
		<script type="text/javascript">
    document.getElementById("Devices-catogery").onclick = function () {
        location.href = "DevicesPage.php";
    };
</script>
			</br>
		</br>
      </figure>
      
     
	  
    </div> <!-- end img gallery wrapper -->
  </div> <!-- end content wrapper -->

    </section>

   
  </div>
  <div class="page-wrapper">
    <div id="waterdrop"></div>
    <footer>
      <div class="footer-top">
        <div class="pt-exebar">

        </div> 
      <div class="footer-bottom">
        <div class="container">
          <div class="row">

            <div class="col-md-3">
              <div id="font" class="footer-site-info">2022 © Design team|All rights reserved</div>
			   <br>
			  <div id="font" class="footer-site-info">Don't be shy to say hi</div>
            </div>

            <div class="col-md-6">
              <nav id="footer-navigation" class="site-navigation footer-navigation centered-box" role="navigation">
			  
			    <br>
	   <ul  id="font" class="rightlist">	  
	    <li class="phone">  <i class="fas fa-phone-square-alt"></i> +966542918273</li>  
		 
               
		
	  </ul>
       <ul id="font" class="leftlist">
	   <li class=" email"><i class="fas fa-envelope"></i> SRE.x@gmail.com</li>  
	     
		
      </ul>
	  <br>
               
              </nav>
            </div>

            <div class="col-md-3">
              <div id="footer-socials">
                <div class="socials inline-inside socials-colored">

                  <a href="#" target="_blank" title="Facebook" class="socials-item">
                    <i class="fab fa-facebook-f facebook"></i>
                  </a>
                  <a href="#" target="_blank" title="Twitter" class="socials-item">
                    <i class="fab fa-twitter twitter"></i>

                  </a>
                  <a href="#" target="_blank" title="Instagram" class="socials-item">
                    <i class="fab fa-instagram instagram"></i>
                  </a>
                  
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </footer>
  </div>
</body>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <script src="https://daniellaharel.com/raindrops/js/raindrops.js"></script>

 <script> jQuery('#waterdrop').raindrops({color:'#1c1f2f', canvasHeight:150, density: 0.1, frequency: 20});
</script>

    <script src="js/index.js"></script>


</html>
