function updateProgram(){
	    document.getElementById("update").onclick =  location.href = "updateProgram.php";
}

function updateDevice(){
	    document.getElementById("update").onclick =  location.href = "updateDevice.php";
}